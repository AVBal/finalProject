package mainpack.db;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import mainpack.exceptions.DatabaseConnectException;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class DataBase {
    private static Connection connection;
    private static Statement stmt;

    public void connect() throws DatabaseConnectException {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:office.db");
            stmt = connection.createStatement();
        } catch (ClassNotFoundException | SQLException e) {
            throw new DatabaseConnectException("Невозможно подключиться к БД");
        }
    }

    public void disconnect() throws DatabaseConnectException {
        try {
            stmt.close();
        } catch (SQLException e) {
            throw new DatabaseConnectException("Невозможно закрыть statement");
        }
        try {
            connection.close();
        } catch (SQLException e) {
            throw new DatabaseConnectException("Невозможно закрыть соединение");
        }
    }

    ArrayList<Workers> readAllFromWorkersAndInfo() throws SQLException {
        ArrayList<Workers> workers = new ArrayList<>();
        try {
            ResultSet rs = stmt.executeQuery("SELECT * FROM Workers, AdditionalInformation " +
                    "WHERE Workers.additional_information = AdditionalInformation.id;");
            while (rs.next()) {
                workers.add(new Workers(rs.getString("name"), rs.getString("position"),
                        rs.getInt("age"), rs.getInt("salary"),
                        rs.getString("phone_number"), rs.getString("address")));
            }
        } catch (SQLException e) {
            throw new SQLException("Невозможно считать данные из БД");
        }
        return workers;
    }

    public void add(String name, String position, int age, int salary, int additionalInfo, String phoneNumber, String address)
            throws SQLException {
        try {
            stmt.executeUpdate("INSERT INTO Workers (name, position, age, salary, additional_information) " +
                    "VALUES ('" + name + "', " + "'" + position + "', " +
                    age + ", " + salary + ", " + additionalInfo + ");");
            stmt.executeUpdate("INSERT INTO AdditionalInformation(id, phone_number, address) " +
                    "VALUES (" + additionalInfo + ", '" + phoneNumber + "', '" + address + "');");
        } catch (SQLException e) {
            throw new SQLException("Невозможно добавить сотрудника");
        }
    }

    public void addFromFile(String file) throws FileNotFoundException, SQLException {
        if (!(new File(file + ".txt").exists())) {
            throw new FileNotFoundException("Текстовый файл не существует");
        }
        Scanner in = new Scanner(new FileInputStream(file + ".txt"));
        String name;
        String position;
        int age;
        int salary;
        int additionalInfo;
        String phoneNumber;
        String address;
        while (in.hasNext()) {
            name = in.next() + " " + in.next() + " " + in.next();
            position = in.next();
            age = in.nextInt();
            salary = in.nextInt();
            additionalInfo = in.nextInt();
            phoneNumber = in.next();
            address = in.nextLine();
            try {
                add(name, position, age, salary, additionalInfo, phoneNumber, address);
            } catch (SQLException e) {
                throw e;
            }
        }
    }

    public void addToJSONFromDB(String file) throws IOException, SQLException {
        if (!(new File(file + ".json").exists())) {
            throw new FileNotFoundException("JSON файл не существует");
        }
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        try (FileWriter writer = new FileWriter(file + ".json")) {
            ArrayList<Workers> workers = readAllFromWorkersAndInfo();
            String worker;
            writer.write("{\"workers\": [ \n");
            for (int i = 0; i < workers.size() - 1; i++) {
                worker = mapper.writeValueAsString(workers.get(i));
                writer.write(worker + ", \n");
            }
            worker = mapper.writeValueAsString(workers.get(workers.size() - 1));
            writer.write(worker + "\n");
            writer.write("] \n }");
        } catch (SQLException e) {
            throw e;
        } catch (IOException e) {
            throw new IOException("Ошибка записи в JSON");
        }
    }

    public int getAVGSalary() throws SQLException {  //can test
        ResultSet rs = null;
        try {
            rs = stmt.executeQuery("SELECT AVG(salary) FROM Workers;");
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new SQLException("Ошибка получения средней зарплаты сотрудников");
        }

        return 0;
    }

    public int getAVGSalaryByPosition(String position) throws SQLException { //can test
        ResultSet rs = null;
        try {
            rs = stmt.executeQuery("SELECT AVG(salary) FROM Workers WHERE position = '" + position + "';");
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            throw new SQLException("Ошибка получения средней зарплаты должности");
        }

        return 0;
    }

    public String getWorkerByPhoneNumber(String phoneNumber) throws SQLException { //can test
        try {
            ResultSet rs = stmt.executeQuery("SELECT name FROM Workers, AdditionalInformation " +
                    "WHERE Workers.additional_information = AdditionalInformation.id and " +
                    "AdditionalInformation.phone_number = '" + phoneNumber + "';");
            if (rs.next()) {
                return rs.getString(1);
            }
        } catch (SQLException e) {
            throw new SQLException("Ошибка нахождения работника по номеру телефона");
        }
        return null;
    }
}
