package mainpack.db;

import mainpack.exceptions.DatabaseConnectException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Main {
    private static final Logger LOGGER = LogManager.getLogger(Main.class);

    public static void main(String[] args) {
        DataBase db = new DataBase();
        try {
            db.connect();
            ArrayList<Workers> workers = db.readAllFromWorkersAndInfo();
            Scanner in = new Scanner(System.in);
            String choice = in.next();
            while (!choice.equals("/exit")) {
                switch (choice) {
                    case "/help":
                        System.out.println("Добавить сотрудника:");
                        System.out.println("/add String name, String position, int age, int salary, " +
                                "int additionalInfo, String phoneNumber, String address");
                        System.out.println();
                        System.out.println("Экспорт из текстового файла в БД:");
                        System.out.println("/addFromFile String fileName");
                        System.out.println();
                        System.out.println("Экспорт из БД в JSON:");
                        System.out.println("/addToJSON String fileName");
                        System.out.println();
                        System.out.println("Получить среднюю зарплату среди сотрудников:");
                        System.out.println("/getAVGSalary");
                        System.out.println();
                        System.out.println("Получить среднюю зарплату по должностям:");
                        System.out.println("/getAVGSalaryByPosition String position");
                        System.out.println();
                        System.out.println("Поиск сотрудника по номеру телефона:");
                        System.out.println("/findByPhone String phoneNumber");
                        System.out.println();
                        System.out.println("Выход:");
                        System.out.println("/exit");
                        System.out.println();
                        System.out.println("ПОМЕТКА: ТИП В ЗАПИСИ НЕ УКАЗЫВАЕТСЯ");
                        break;
                    case "/add":
                        String name = in.next() + " " + in.next() + " " + in.next();
                        String position = in.next();
                        int age = in.nextInt();
                        int salary = in.nextInt();
                        int additionalInfo = in.nextInt();
                        String phoneNumber = in.next();
                        String address = in.next();
                        db.add(name, position, age, salary, additionalInfo, phoneNumber, address);
                        break;
                    case "/addFromFile":
                        String fileName = in.next();
                        db.addFromFile(fileName);
                        break;
                    case "/addToJSON":
                        fileName = in.next();
                        db.addToJSONFromDB(fileName);
                        break;
                    case "/getAVGSalary":
                        System.out.println(db.getAVGSalary() + " рублей");
                        break;
                    case "/getAVGSalaryByPosition":
                        System.out.println(db.getAVGSalaryByPosition(in.next()));
                        break;
                    case "/findByPhone":
                        System.out.println(db.getWorkerByPhoneNumber(in.next()));
                        break;
                    default:
                        System.out.println("Введите /help, чтобы получить справку");
                        break;
                }
                choice = in.next();
            }
        } catch (DatabaseConnectException e) {
            LOGGER.error( "Ошибка соединения с БД" );
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            LOGGER.error( "Указанный файл не существует" );
            e.printStackTrace();
        } catch (SQLException e) {
            LOGGER.error( "Ошибка изменения базы данных" );
            e.printStackTrace();
        } catch (IOException e) {
            LOGGER.error( "Ошибка записи в JSON" );
            e.printStackTrace();
        } finally {
            try {
                db.disconnect();
            } catch (DatabaseConnectException e) {
                e.printStackTrace();
            }
        }
    }
}
