package mainpack;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        DataBase db = new DataBase();
        ArrayList<Workers> workers = new ArrayList<>();
        try {
            db.connect();
            db.addFromFile("input.txt");
            db.readAllFromWorkersAndInfo(workers);
            for (Workers o : workers) {
                System.out.println(o);
            }
            System.out.println(db.getAVGSalary());
            System.out.println(db.getAVGSalaryByPosition("Бухгалтер"));
            System.out.println(db.getWorkerByPhoneNumber("242-53-34"));
        } catch (NullPointerException e) {
            e.printStackTrace();
        } finally {
            db.disconnect();
        }
    }
}
