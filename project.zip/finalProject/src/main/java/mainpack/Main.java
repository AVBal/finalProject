package mainpack;

import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        DataBase db = new DataBase();
        ArrayList<Workers> workers;
        try {
            db.connect();
            //db.addFromFile("input.txt")
            db.addToJSONFromDB("output.json");
            workers = db.readAllFromWorkersAndInfo();
            for (Workers o : workers) {
                System.out.println(o);
            }
            System.out.println(db.getAVGSalary());
            System.out.println(db.getAVGSalaryByPosition("Бухгалтер"));
            System.out.println(db.getWorkerByPhoneNumber("242-53-34"));
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            db.disconnect();
        }
    }
}
