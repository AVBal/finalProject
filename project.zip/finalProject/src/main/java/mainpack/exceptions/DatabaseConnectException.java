package mainpack.exceptions;

public class DatabaseConnectException extends RuntimeException {

    public DatabaseConnectException() {
        super("Ошибка соединения с БД");
    }

    public DatabaseConnectException(String message) {
        super(message);
    }
}
