package mainpack;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class DataBase {
    private static Connection connection;
    private static Statement stmt;

    public void connect() throws RuntimeException {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:office.db");
            stmt = connection.createStatement();
        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException("Невозможно подключиться к базе данных");
        }
    }

    public void disconnect() {
        try {
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    ArrayList<Workers> readAllFromWorkersAndInfo() {
        ArrayList<Workers> workers = new ArrayList<>();
        try {
            ResultSet rs = stmt.executeQuery("SELECT * FROM Workers, AdditionalInformation " +
                    "WHERE Workers.additional_information = AdditionalInformation.id;");
            while (rs.next()) {
                workers.add(new Workers(rs.getString("name"), rs.getString("position"),
                        rs.getInt("age"), rs.getInt("salary"),
                        rs.getString("phone_number"), rs.getString("address")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return workers;
    }

    public void add(String name, String position, int age, int salary, int additionalInfo, String phoneNumber, String address) {
        try {
            stmt.executeUpdate("INSERT INTO Workers (name, position, age, salary, additional_information) " +
                    "VALUES ('" + name + "', " + "'" + position + "', " +
                    age + ", " + salary + ", " + additionalInfo + ");");
            stmt.executeUpdate("INSERT INTO AdditionalInformation(id, phone_number, address) " +
                    "VALUES (" + additionalInfo + ", '" + phoneNumber + "', '" + address + "');");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addFromFile(String file) throws FileNotFoundException {
        if (!(new File(file).exists())) {
            throw new FileNotFoundException();
        }
        Scanner in = new Scanner(new FileInputStream(file));
        String name;
        String position;
        int age;
        int salary;
        int additionalInfo;
        String phoneNumber;
        String address;
        while (in.hasNext()) {
            name = in.next() + " " + in.next() + " " + in.next();
            position = in.next();
            age = in.nextInt();
            salary = in.nextInt();
            additionalInfo = in.nextInt();
            phoneNumber = in.next();
            address = in.nextLine();
            add(name, position, age, salary, additionalInfo, phoneNumber, address);
        }
    }

    public void addToJSONFromDB(String file) throws FileNotFoundException {
        if (!(new File(file).exists())) {
            throw new FileNotFoundException();
        }
        ArrayList<Workers> workers = readAllFromWorkersAndInfo();
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        String worker;
        try (FileWriter writer = new FileWriter(file, true)){
            writer.write("{\"workers\": [ \n");
            for (int i = 0; i < workers.size() - 1; i++) {
                worker = mapper.writeValueAsString(workers.get(i));
                writer.write(worker + ", \n");
            }
            worker = mapper.writeValueAsString(workers.get(workers.size() - 1));
            writer.write(worker + "\n");
            writer.write("] \n }");
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getAVGSalary() {
        try {
            ResultSet rs = stmt.executeQuery("SELECT AVG(salary) FROM Workers;");
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getAVGSalaryByPosition(String position) {
        try {
            ResultSet rs = stmt.executeQuery("SELECT AVG(salary) FROM Workers WHERE position = '" + position + "';");
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public String getWorkerByPhoneNumber(String phoneNumber) {
        try {
            ResultSet rs = stmt.executeQuery("SELECT name FROM Workers, AdditionalInformation " +
                    "WHERE Workers.additional_information = AdditionalInformation.id and " +
                    "AdditionalInformation.phone_number = '" + phoneNumber + "';");
            if (rs.next()) {
                return rs.getString(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
