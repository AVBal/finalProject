package mainpack;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class DataBase {
    private static Connection connection;
    private static Statement stmt;
    private ArrayList<Workers> workers;

    public void connect() {
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:office.db");
            stmt = connection.createStatement();
        } catch (ClassNotFoundException | SQLException e) {
            new RuntimeException("Невозможно подключиться к базе данных");
        }
    }

    public void disconnect() {
        try {
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void readAllFromWorkersAndInfo(ArrayList<Workers> workers) {
        this.workers = workers;
        try {
            ResultSet rs = stmt.executeQuery("SELECT * FROM Workers, AdditionalInformation " +
                    "WHERE Workers.additional_information = AdditionalInformation.id;");
            while (rs.next()) {
                workers.add(new Workers(rs.getString("name"), rs.getString("position"),
                        rs.getInt("age"), rs.getInt("salary"),
                        rs.getString("phone_number"), rs.getString("address")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void add(String name, String position, int age, int salary, int additionalInfo, String phoneNumber, String address) {
        try {
            stmt.executeUpdate("INSERT INTO Workers (name, position, age, salary, additional_information) " +
                    "VALUES ('" + name + "', " + "'" + position + "', " +
                    age + ", " + salary + ", " + additionalInfo + ");");
            stmt.executeUpdate("INSERT INTO AdditionalInformation(id, phone_number, address) " +
                    "VALUES (" + additionalInfo + ", '" + phoneNumber + "', '" + address + "');");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addFromFile(String file) {
        try (Scanner in = new Scanner(new FileInputStream(file))) {
            String name;
            String position;
            int age;
            int salary;
            int additionalInfo;
            String phoneNumber;
            String address;
            while (in.hasNext()) {
                name = in.next() + " " + in.next() + " " + in.next();
                position = in.next();
                age = in.nextInt();
                salary = in.nextInt();
                additionalInfo = in.nextInt();
                phoneNumber = in.next();
                address = in.nextLine();
                add(name, position, age, salary, additionalInfo, phoneNumber, address);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public int getAVGSalary() {
        try {
            ResultSet rs = stmt.executeQuery("SELECT AVG(salary) FROM Workers;");
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int getAVGSalaryByPosition(String position) {
        try {
            ResultSet rs = stmt.executeQuery("SELECT AVG(salary) FROM Workers WHERE position = '" + position + "';");
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public String getWorkerByPhoneNumber(String phoneNumber) {
        try {
            ResultSet rs = stmt.executeQuery("SELECT name FROM Workers, AdditionalInformation " +
                    "WHERE Workers.additional_information = AdditionalInformation.id and " +
                    "AdditionalInformation.phone_number = '" + phoneNumber + "';");
            if (rs.next()) {
                return rs.getString(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
