package mainpack.db.classes;

public class Workers {
    private String name;
    private String position;
    private int age;
    private int salary;
    private String phoneNumber;
    private String address;

    public Workers() {
    }

    public Workers(String name, String position, int age, int salary, String phoneNumber, String address) {
        this.name = name;
        this.position = position;
        this.age = age;
        this.salary = salary;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return name + " " + position + " " + age + " " +
                salary + " " + phoneNumber + " " + address;
    }
}
