package mainpack;

public class Workers {
    private String name;
    private String position;
    private int age;
    private int salary;
    private String phoneNumber;
    private String address;

    public Workers(String name, String position, int age, int salary, String phoneNumber, String address) {
        this.name = name;
        this.position = position;
        this.age = age;
        this.salary = salary;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    @Override
    public String toString() {
        return name + " " + position + " " + age + " " +
                salary + " " + phoneNumber + " " + address;
    }
}
